## 8. 样式规范

### 8.1 Tailwind 使用

- 优先使用 Tailwind 原子类，复杂样式使用 `@/styles` 中预定义的样式对象
- 数值类使用方括号语法：`gap-[10px]`、`p-[10px]`、`w-[250px]`、`min-w-[96px]`
- 颜色使用系统主题色：`text-[#1677ff]`（主色）、`text-[#ff4d4f]`（错误/危险）
- 布局间距：页面内模块间距 `gap-[10px]` / `space-y-[5px]`，按钮间距 `space-x-[10px]`

### 8.2 预定义样式（`@/styles`）

| 样式名 | 用途 |
|--------|------|
| `styles.formLeft` | 表单左侧标签 |
| `styles.formLeftStar` | 必填星号 |
| `styles.formError` | 表单错误提示行 |
| `styles.infoLineBT` | 详情行（带边框） |
| `styles.infoLineName` | 详情字段名（灰色背景居中） |
| `styles.infoLineDes` | 详情字段值 |
| `styles.moduleTitleText` | 小模块标题 |

### 8.3 CSS Modules / 全局样式

- 如果使用普通 CSS/Less，以组件名作为类名前缀进行 BEM 命名
- 避免使用标签选择器、ID 选择器定义样式（JS 操作 DOM 除外）
- 修改 Ant Design 样式时，通过 `className` 或 `style` API 传入，避免直接覆盖全局样式
- 如需深度修改，使用 CSS Modules 的 `:global()` 并加上明确作用域限定

### 8.4 CSS 属性书写顺序

1. 定位属性（position、top、left、z-index、display、float）
2. 宽高属性（width、height、max-width、max-height）
3. 边距属性（margin、padding、border）
4. 字体、背景、颜色（font、color、background、line-height）

---
