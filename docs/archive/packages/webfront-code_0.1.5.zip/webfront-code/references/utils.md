## 工具函数规范（utils）

### method.jsx 工具函数

项目统一使用 `@/utils/method` 中的工具函数：

#### 1. stringify - URL 参数拼接

```jsx
import { stringify } from '@/utils/method';

// 将对象转换为 URL 查询字符串
const params = { page: 1, size: 10, search: 'keyword' };
const queryString = stringify(params); // "page=1&size=10&search=keyword"
```

#### 2. calculateNewPage - 计算删除后的页码

删除操作后必须使用此函数重新计算当前页码，避免删除后页面显示为空。

```jsx
import { calculateNewPage } from '@/utils/method';

// 在 store 的 delete action 中使用
filter.page = calculateNewPage(filter.page, filter.size, list.count, deletedCount);
```

**参数说明**：

| 参数 | 类型 | 说明 |
|------|------|------|
| currentPage | number | 当前页码 |
| size | number | 每页条数 |
| originalCount | number | 删除前的总条数 |
| deletedCount | number | 删除的条数 |

**返回值**：新的页码（number）

#### 3. downloadBlob - Blob 文件下载

用于导出功能的文件下载，自动处理文件名解析。

```jsx
import { downloadBlob } from '@/utils/method';

// 在 store 的 export action 中使用
exportXxx: async (params) => {
    set({ loading: { ...get().loading, export: true } });
    const { data, headers, error } = await service.exportXxx(params);
    set({ loading: { ...get().loading, export: false } });
    if (data) {
        downloadBlob(data, headers);
        message.success('导出成功');
        return true;
    }
    if (error) {
        message.error(error?.error || '导出失败');
    }
}
```

**特性**：

- 自动从 `Content-Disposition` 头解析文件名
- 支持 `filename*` UTF-8 编码格式
- 根据 MIME 类型自动推断文件扩展名
- 导出失败时自动提示错误

### request.jsx 请求封装

#### cancelAllRequests - 取消所有请求

页面销毁时调用，避免内存泄漏和竞态条件。

```jsx
import { cancelAllRequests } from '@/utils/request';

// 在页面组件的 useEffect 中使用
useEffect(() => {
    return () => {
        cancelAllRequests();
        clearData();
    };
}, []);
```

**注意**：

- 必须在组件卸载时调用
- 配合 `clearData()` 一起使用，确保状态重置
- 这是典型的“仅卸载清理”场景，依赖数组保持 `[]` 即可，不要机械把稳定函数都加入依赖数组

---

## 工具函数实现代码

如果项目中没有这些工具函数，可以按以下代码创建：

### method.jsx 完整代码

```jsx
import { message } from 'antd';

// 处理url参数对象
export const stringify = (search) => {
    if (search === null || search === undefined) {
        return ''
    }
    return Object.entries(search).reduce((a, b, i) => {
        if ((b[1] ?? '') !== '') {
            if (Array.isArray(b[1])) {
                for (var j = 0; j < b[1].length; j++) {
                    if (b[1][j] !== '') {
                        a += `${a === '' ? '' : '&'}${encodeURIComponent(b[0])}=${encodeURIComponent(b[1][j])}`
                    }
                }
            } else {
                a += `${a === '' ? '' : '&'}${encodeURIComponent(b[0])}=${encodeURIComponent(b[1])}`
            }
        }
        return a
    }, '')
}

// 计算新的当前页码
export const calculateNewPage = (currentPage, size, originalCount, deletedCount) => {
    const newCount = Math.max(0, originalCount - deletedCount);
    const maxPage = Math.max(1, Math.ceil(newCount / size));
    return Math.min(currentPage, maxPage);
}

// Blob文件下载
export const downloadBlob = (data, headers) => {
    const contentType = headers?.['content-type'] || '';
    if (contentType.includes('text/html')) {
        message.error('导出失败');
        return;
    }
    const blob = new Blob([data]);
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const disposition = headers?.['content-disposition'] || '';
    let fileName = '';
    if (disposition) {
        const match = disposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/);
        if (match) {
            fileName = decodeURIComponent(match[1].replace(/['"]/g, ''));
        } else {
            const starMatch = disposition.match(/filename\*=utf-8''(.+?)(?:;|$)/i);
            if (starMatch) {
                fileName = decodeURIComponent(starMatch[1]);
            }
        }
    }
    if (!fileName) {
        const mimeToExt = {
            'application/zip': 'download.zip',
            'application/x-zip-compressed': 'download.zip',
            'application/x-compressed': 'download.zip',
            'application/octet-stream': 'download.bin',
            'text/plain': 'download.txt',
            'application/json': 'download.json',
            'application/pdf': 'download.pdf',
            'application/vnd.ms-excel': 'download.xls',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'download.xlsx',
        };
        fileName = mimeToExt[blob.type] || 'download';
    }
    link.download = fileName;

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
}
```

### request.jsx 完整代码

```jsx
import { message } from 'antd';
import axios from 'axios';
import qs from 'qs';

const service = axios.create({
    timeout: 1000 * 60 * 60 * 8,
    validateStatus: (status) => {
        return true
    },
    paramsSerializer: (params) => qs.stringify(params, { indices: false }),
})

// 添加请求中断映射表
const cancelTokenMap = new Map();

// 请求拦截器
service.interceptors.request.use(
    async (config) => {
        const token = localStorage.getItem('token')
        if (token) {
            config.headers['Authorization'] = `Token ${encodeURIComponent(token)}`
        }
        if (!config.keepAlive) {
            const controller = new AbortController();
            config.signal = controller.signal;
            cancelTokenMap.set(config.url, controller);
        }
        return config
    },
    (err) => {
        err.message = '服务器异常，请联系管理员！'
        return Promise.reject(err)
    }
)

// 响应拦截器
service.interceptors.response.use(
    response => {
        const status = response.status;
        if (response.config.responseType === 'blob') {
            return Promise.resolve({ data: response.data, headers: response.headers, error: false });
        }
        if (status === 200 || status === 201) {
            return Promise.resolve({ data: response.data, headers: response.headers, error: false });
        } else if (status === 400) {
            return Promise.resolve({ error: response.data, data: false });
        } else if (status === 403) {
            return Promise.resolve({ error: response.data, data: false });
        } else if (status === 404) {
            return Promise.resolve({ not_found: { error: '404!' }, data: false, error: false });
        } else {
            message.error('服务器异常！')
            return Promise.resolve({ data: false, error: false, headers: response.headers });
        }
    },
    (err) => {
        if (axios.isCancel(err)) {
            return Promise.resolve({ canceled: true });
        }
        return Promise.reject(err);
    }
)

export default service;

// 取消所有请求的方法
export const cancelAllRequests = () => {
    cancelTokenMap.forEach(controller => controller.abort());
    cancelTokenMap.clear();
};
```

---
