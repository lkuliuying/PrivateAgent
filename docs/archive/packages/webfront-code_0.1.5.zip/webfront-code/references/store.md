## 5. 状态管理规范（Zustand）

### 5.1 文件位置

每个模块一个 `store.jsx`，与页面组件同目录。

### 5.2 Store 使用规范

**组件中使用 Store 必须遵循以下规则**：

1. **统一解构获取**：组件中所有需要从 store 获取的状态和方法，必须在组件顶部通过解构一次性获取
2. **禁止直接访问**：禁止在组件内部使用 `store.getState()` 直接访问 store 中的状态或方法
3. **依赖按语义声明**：useEffect、useCallback、useMemo 等 Hooks 的依赖数组只声明真正参与重新计算或副作用触发的值；不要机械把所有函数都加入依赖数组。对于稳定的 store 方法、仅用于卸载清理的方法，可结合场景使用空数组并补充简短说明

**✅ 正确示例**：

```jsx
const Index = () => {
    // 所有需要的状态和方法在此处解构获取
    const { filter, list, loading, updates, getList, clearData } = store();

    useEffect(() => {
        getList(filter);
    }, [filter]);

    useEffect(() => {
        return () => {
            clearData();
        };
        // 仅在组件卸载时清理状态，不需要因为稳定的 store 方法引用而重跑 effect
    }, []);
}
```

**❌ 错误示例**：

```jsx
const Index = () => {
    const { filter, list } = store();

    useEffect(() => {
        // 错误：使用 store.getState() 直接访问
        store.getState().clearData();
    }, []);
}
```

**补充说明**：

- 依赖数组的目标是描述 effect 何时需要重新执行，不是把作用域里出现的标识符机械补全
- 如果 effect 只负责根据 `filter` 拉取数据，优先依赖 `filter`，不要额外把稳定的 store action 一并加入
- 如果 effect 只负责组件卸载时清理，可使用 `[]`，并在必要时用注释说明这是“仅卸载清理”场景
- 如果某个函数引用本身会变化，并且 effect 的业务语义确实依赖它，再把该函数加入依赖数组

### 5.3 State 结构（必须遵循）

```jsx
export const store = create((set, get) => ({
    // ===== 通用状态 =====
    loading: {},           // 加载状态：{ list: true, edit: false, delete: false, ... }
    open: {},              // 弹框/抽屉开关：{ edit: false, detail: false, delete: false, ... }
    filter: { page: 1, size: 10, search: '' },  // 列表查询条件
    list: { count: 0, results: [] },            // 列表数据
    selected: [],          // 表格选中行的 id 数组
    isAll: false,          // 是否全量操作（如全量检测）

    // ===== 业务状态 =====
    detail: {},            // 详情数据
    form: {},              // 表单数据
    errMsg: {},            // 表单校验错误信息

    // ===== 通用方法 =====
    updates: (params) => set({ ...params }),
    clearData: () => set({ /* 重置所有状态为初始值 */ }),
}))
```

### 5.4 Action 命名规范

| 操作 | 命名 |
|------|------|
| 获取列表 | `getList` |
| 获取详情 | `getDetail` |
| 新增 | `addXxx` |
| 编辑 | `editXxx` |
| 删除 | `deleteXxx` |
| 批量操作 | `batchXxx` |

### 5.5 Action 代码模板

```jsx
getList: async (params) => {
    set({ loading: { ...get().loading, list: true } });
    const { data, error } = await service.getList(params);
    set({ loading: { ...get().loading, list: false } });
    if (data?.results) {
        set({ list: data, selected: [] });
    }
},

deleteXxx: async (params) => {
    set({ loading: { ...get().loading, delete: true } });
    const { data, error } = await service.deleteItem(params);
    set({ loading: { ...get().loading, delete: false } });
    if (data?.status === 1) {
        message.success('操作成功');
        let filter = get().filter;
        const list = get().list;
        filter.page = calculateNewPage(filter.page, filter.size, list.count, params.ids.length);
        set({
            filter: { ...filter },
            selected: [],
            open: {}
        });
        return true
    }
    if (error) {
        set({ errMsg: error });
    }
},
```

**注意**：

- 成功判断统一使用 `data?.status === 1`
- 删除操作后必须使用 `calculateNewPage` 重新计算页码
- 操作成功后清空 `selected` 和 `open`
- 返回值：成功返回 `true`，失败不返回或返回 `false`
- Action 中正确管理 loading 状态（开始 true，结束 false）
- **删除规范**：删除操作的 ID 统一通过 `selected` 数组传递，单条删除时 `selected = [id]`，删除函数内部取 `selected[0]`。后端未提供批量删除接口时，**禁止**用单个删除接口循环调用实现批量删除，批量删除按钮应 disabled 或提示用户暂不支持

### 5.6 Store 文件函数组织规范

`store.jsx` 中的函数按职责分为两类，组织顺序必须遵循以下规则：

1. **接口 Action**：所有涉及网络请求的异步函数（如 `getList`、`addXxx`、`editXxx`、`deleteXxx` 等）放在前面。
2. **通用方法**：`updates` 和 `clearData` 始终放在 store 文件的最后。

**禁止放入 store 的函数**：纯前端状态更新逻辑（不涉及接口调用）。此类逻辑应在页面组件中通过 `updates` 处理，保持 store 仅作为"数据层"。

**示例**：

```jsx
export const store = create((set, get) => ({
    // ===== 状态定义 =====
    loading: {},
    open: {},
    list: { count: 0, results: [] },

    // ===== 接口 Action（放前面） =====
    getList: async (params) => { /* ... */ },
    addItem: async (params) => { /* ... */ },
    deleteItem: async (params) => { /* ... */ },

    // ===== 通用方法（始终放最后） =====
    updates: (params) => set({ ...params }),
    clearData: () => set({ /* 重置初始值 */ }),
}))
```

**反例**（不要在 store 中写纯前端计算逻辑）：

```jsx
// ❌ 错误：纯前端状态更新不应放在 store 中
updateBaseScore: (key, value) => {
    const numValue = parseInt(value, 10);
    const clampedValue = Math.max(1, Math.min(999, numValue));
    set({ baseScores: { ...get().baseScores, [key]: clampedValue } });
},

// ✅ 正确：放到页面组件中，通过 updates 修改
const handleBaseScoreChange = (key, value) => {
    const numValue = parseInt(value, 10);
    if (isNaN(numValue)) return;
    const clampedValue = Math.max(1, Math.min(999, numValue));
    updates({ baseScores: { ...baseScores, [key]: clampedValue } });
};
```

---
