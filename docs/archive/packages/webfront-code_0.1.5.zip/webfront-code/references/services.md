## 4. 接口服务规范（services）

### 4.1 代码模板

```jsx
import request from "@/utils/request";
import { stringify } from "@/utils/method";

// 获取列表
export const getList = (params) => {
    return request(`/api/xxx/?${stringify(params)}`)
}

// 新增
export const addItem = (params) => {
    return request(`/api/xxx/`, {
        method: 'POST',
        data: params,
    })
}

// 编辑
export const editItem = (params) => {
    return request(`/api/xxx/${params.id}/`, {
        method: 'PATCH',
        data: params,
    })
}

// 删除/批量删除
export const deleteItem = (params) => {
    return request(`/api/xxx/delete/`, {
        method: 'DELETE',
        data: params,
    })
}
```

### 4.2 统一导出

```jsx
// services/index.jsx
import * as moduleName from './ModuleName/service';

export {
    moduleName,
    // ...
}
```

**规则**：

- 使用 `@/utils/request` 发送请求
- 使用 `@/utils/method` 中的 `stringify` 拼接查询参数
- 按 CURD + 业务操作顺序排列接口
- 每个接口必须写注释说明用途
- 网络请求函数名见名知意，必要时写 JSDoc 注释

---
