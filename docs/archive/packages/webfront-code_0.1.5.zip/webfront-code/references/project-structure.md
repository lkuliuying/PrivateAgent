## 3. 项目目录结构

```
src/
├── pages/                      # 页面级模块
│   └── Resource/
│       └── ModuleName/
│           ├── index.jsx         # 页面入口（路由组件），负责布局组装
│           ├── store.jsx         # Zustand 状态管理（唯一状态源）
│           ├── edit.jsx          # 新增/编辑 Drawer
│           ├── detail.jsx        # 详情 Drawer
│           ├── auth.jsx          # 授权/批量操作 Drawer/Modal
│           └── ...               # 其他子组件
├── services/                     # 接口服务
│   ├── index.jsx                 # 统一导出所有模块 service（命名空间导入）
│   └── ModuleName/
│       └── service.jsx           # 模块接口文件
├── components/                   # 通用组件
│   ├── DelModal.jsx              # 删除/回收确认弹框
│   └── Confirm.jsx               # 操作确认弹框
├── utils/
│   ├── request.jsx               # 统一请求封装（axios）
│   └── method.jsx                # 工具方法（stringify, calculateNewPage 等）
├── styles/                       # 预定义样式对象
│   └── index.jsx                 # formLeft, infoLineBT 等
├── hooks/                        # 自定义 Hooks
└── router/                       # 路由配置
```

**文件夹命名**：小写开头；页面级文件夹以 `Page` 或 `Screen` 结尾；通用文件夹用 `components/hooks/utils/services/store`。

**文件命名**：

- 页面组件：PascalCase，如 `index.jsx`, `edit.jsx`, `NodeList.jsx`
- Service 文件：小写驼峰，如 `exportIP.jsx`, `vpn.jsx`
- Store 文件：统一 `store.jsx`

---
