## 7. Drawer / Modal 规范

### 7.1 编辑 Drawer

```jsx
<Drawer
    title={`${form?.id ? '编辑' : '新增'}名称`}
    closable={false}
    onClose={onClose}
    open={open.edit}
    width={600}
    destroyOnHidden={true}
    footer={
        <div className='text-center space-x-[10px]'>
            <Button className='min-w-[96px]' onClick={onClose}>取消</Button>
            <Button className='min-w-[96px]' type='primary' loading={loading?.edit} onClick={onSubmit}>保存</Button>
        </div>
    }
>
```

### 7.2 表单布局

必须使用 `Row` + `Col` 布局，左侧标签固定宽度（通常为 `100px`）：

```jsx
<Row>
    <Col className={styles.formLeft} flex='100px'><b className={styles.formLeftStar}>*</b>字段名：</Col>
    <Col flex='auto'>
        <Input
            placeholder='请输入'
            value={form?.field}
            onChange={(e) => changeData('field', e.target.value)}
            onFocus={() => clearErr('field')}
        />
    </Col>
</Row>
<Row className={styles.formError}>
    <Col flex='100px'></Col>
    <Col flex='auto'>{errMsg.field}</Col>
</Row>
```

### 7.3 详情 Drawer

```jsx
<div className='break-words border border-b_c border-solid border-b-0'>
    <Row className={styles.infoLineBT}>
        <Col flex={'120px'} className={styles.infoLineName}>字段名</Col>
        <Col flex={'auto'} className={styles.infoLineDes}>
            <span className="font-mono text-[#1677ff] font-medium">{detail?.field || '--'}</span>
        </Col>
    </Row>
</div>
```

**值的展示要求**：

- IP 地址、机源码等技术字段：蓝色/灰色 `font-mono` 等宽字体
- 状态类字段：使用 `Tag` 或图标 + 文字，禁止纯文本展示状态
- 空值统一展示 `'--'`

### 7.4 确认弹框

**删除/回收（DelModal）**：

```jsx
<DelModal
    loading={loading?.delete}
    title='模块名称'
    onClose={() => updates({ open: { ...open, delete: false } })}
    onDelete={() => deleteItem({ ids: selected })}
    visible={open?.delete}
/>
```

**操作确认（Confirm）**：

```jsx
<Confirm
    loading={loading?.detection}
    title='进行连通性检测'
    onClose={() => updates({ open: { ...open, detection: false } })}
    onConfirm={() => batchDetection(isAll ? {} : { ids: selected })}
    visible={open?.detection}
/>
```

**授权弹框**：

- 单条授权和批量授权共用同一个授权组件
- 单条授权时设置 `selected: [record.id]` 后打开授权弹框
- 授权组件内展示当前选中的记录列表（Tag 形式）
- 需要获取项目列表作为下拉选项

---
