## 9. 命名规范

### 9.1 变量/函数命名

| 类型 | 命名规范 | 示例 |
|------|----------|------|
| 组件名 | PascalCase | `NodeList`, `BatchAuthorize` |
| 普通变量 | camelCase | `filter`, `selected`, `projectList` |
| 布尔状态 | 语义化命名 | `isAll`, `open.edit`, `loading.list` |
| Action | 动词 + 名词 | `getList`, `deleteVPN`, `batchAuthorize` |
| 事件处理 | handle + 动作 | `handleDelete`, `handleDetection`, `onSubmit` |
| 路由 path | kebab-case 小写 | `/user-center`, `/login` |

### 9.2 组件命名语义

组件名应该以高级别的（通常是一般化描述的）单词开头，以描述性的修饰词结尾。

- **推荐**：`SearchButton`、`SettingsCheckbox`
- **避免**：`ButtonSearch`、`CheckboxSettings`

---

## 10. 编码风格

### 10.1 基础规则

- 不再使用 `var`，统一使用 `let` 和 `const`，优先使用 `const`
- 静态字符串一律使用单引号，动态字符串（含变量插值）使用反引号
- 变量比较时，尽量使用 `===` 和 `!==` 进行严格比较
- 优先使用解构赋值，对象属性采用简洁表达法
- 尽量使用箭头函数，事件处理函数以 `handle` 开头
- 开发完成后，删除所有 `console.log` / `console.warn`

### 10.2 JSX 规范

- 避免清一色 `div`，优先使用语义化标签（header、main、section、article、nav、footer）
- 统一采用 `.jsx` 结尾的单文件组件
- 标签中有多个属性时，分行书写，每个属性占一行
- 空的标签体使用自闭合语法：`<img src={url} alt='描述' />`
- 组件中只包含简单的 JSX 表达式，复杂逻辑提取为独立函数或使用 `useMemo`

### 10.3 Props 规范

- Props 必须提供默认值
- Props 不可直接修改，需通过回调函数通知父组件修改
- 复杂状态逻辑使用 Zustand 或

### 10.4 注释规范

- 接口函数、store action、复杂业务函数必须添加简洁中文注释说明用途
- 复杂参数、返回值、边界条件或副作用不直观时，应使用 JSDoc 说明
- 注释应解释“为什么这样做”或“这段逻辑处理什么业务规则”，避免重复代码表面含义
- 临时调试注释、废弃代码注释、无意义分隔注释在提交前必须删除
- JSX 中只在结构复杂、业务区块较多或条件渲染不直观时添加少量区块注释

### 10.5 路由规范

```jsx
const routes = [
    {
        path: '/user-center',
        element: <UserCenterPage />, // 或 lazy 加载
    },
    {
        path: '/login',
        element: <LoginPage />,
    },
];
```

---

## 11. 错误处理规范

1. **接口错误**：统一由 request 拦截器处理，store action 中只需将 error 设置到 `errMsg`
2. **表单校验错误**：提交前在 `submitMiddle` 中校验，错误信息设置到 `errMsg`，对应字段聚焦时清除错误
3. **操作成功提示**：使用 `message.success('操作成功')`，文案使用中文
4. **空数据处理**：列表空时后端可能不返回 results，需做防御性判断 `data?.results`
5. **请求取消**：如果 request.jsx 中封装了取消请求方法，页面销毁时调用该方法取消进行中的请求（上传功能需谨慎）

---
