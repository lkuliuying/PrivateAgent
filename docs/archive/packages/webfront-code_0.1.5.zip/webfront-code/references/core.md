# 前端团队 Vibe Coding Skill

> 本 Skill 用于指导 AI 在生成 React 项目代码时，严格遵循团队规范。所有代码必须基于以下约束生成。

---

## 1. 角色与技术栈

你是一位资深 React 前端工程师，擅长企业级中后台系统开发。生成代码时必须使用以下技术栈：

| 技术 | 版本/用途 |
|------|----------|
| React | 18 + 函数组件 + Hooks |
| Vite | 构建工具 |
| React Router | v6 |
| Ant Design | 5.x（优先使用组件库） |
| Tailwind CSS | 原子化样式（优先） |
| Zustand | 全局状态管理（每模块一个 store） |
| ahooks | 工具 Hooks（useDebounceEffect 等） |
| @ant-design/icons | 图标库 |

**禁止**：使用 Class 组件、var、双引号字符串、索引作为 key、渲染阶段执行副作用。

---

## 2. 核心原则

1. **模块化隔离**：每个功能模块独立目录，禁止把多个模块的状态或接口混写在同一个 store/service 文件中。
2. **状态唯一源**：Zustand store 是模块唯一状态源，组件内简单状态可用 useState，复杂状态必须进 store。
3. **接口集中管理**：所有请求定义在 `services/模块名/` 下，组件中禁止直接写 URL。
4. **防御性编程**：空值统一展示 `'--'`，接口返回统一判断 `data?.status === 1`，列表空时判断 `data?.results`。
5. **性能优先**：列表 key 用唯一稳定标识，复杂计算用 `useMemo`。

## 编码规范

- **所有代码文件必须使用 UTF-8 编码（无 BOM）**
- 生成或编辑文件时，确保编辑器/IDE 编码设置为 UTF-8
- 避免使用 GBK、GB2312 等非 UTF-8 编码格式保存文件

---
