## 12. AI 生成代码检查清单

生成代码后，必须按以下清单自检：

- [ ] Store 是否包含 `loading`、`open`、`filter`、`list`、`selected` 等通用状态
- [ ] Action 是否正确管理 loading 状态（开始 true，结束 false）
- [ ] 删除操作后是否调用了 `calculateNewPage`
- [ ] 表单是否使用 Row/Col 布局，左侧标签宽度是否统一
- [ ] 详情字段值是否使用合适的样式（Tag、图标、monospace 字体），避免纯文本堆砌
- [ ] 接口 URL 是否从对应 service 文件导入，不在组件中直接写 URL
- [ ] 弹框关闭时是否正确重置了对应状态和表单数据
- [ ] 批量操作按钮是否有 `disabled={selected.length === 0}`
- [ ] 是否引入了未使用的变量或组件
- [ ] 是否符合现有路由和菜单结构
- [ ] 列表渲染 key 是否使用唯一稳定标识（非索引）
- [ ] 字符串是否使用单引号，动态字符串是否使用反引号
- [ ] 是否删除了所有 console 输出
- [ ] 变量是否优先使用 const，是否使用 === 进行比较
- [ ] 接口函数、store action、复杂业务逻辑是否添加了必要注释
- [ ] 如安装了新的依赖包，是否检查对应 package.json 的 dependencies 或 devDependencies 已增加该依赖
