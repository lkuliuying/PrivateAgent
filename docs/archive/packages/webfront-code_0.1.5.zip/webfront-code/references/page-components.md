## 6. 页面组件规范（index.jsx）

### 6.1 组件内部代码顺序

```jsx
// 1. 外部模块导入（按：第三方库 → 全局组件 → 本地组件 → 样式）
import { useEffect } from 'react';
import { Breadcrumb, Input, Button, Table, Pagination } from 'antd';
import { useDebounceEffect } from 'ahooks';
import { store } from './store';
import Edit from './edit';
import Detail from './detail';
import Auth from './auth';
import DelModal from '@/components/DelModal';
import Confirm from '@/components/Confirm';

// 2. 组件定义
const Index = () => {
    // 3. Hooks 调用（按执行顺序）
    // 所有需要从 store 中使用的状态和方法，必须在此处解构获取
    // 禁止在组件其他位置使用 store.getState() 直接访问 store
    const { filter, list, loading, selected, open, isAll, updates, getList, deleteItem, batchDetection, clearData } = store();

    useEffect(() => {
        // 如需要初始化加载数据，在此处调用
        // getList(filter);
        return () => {
            clearData();
        };
        // 仅在组件卸载时清理模块状态，不要机械补齐无业务意义的函数依赖
    }, []);

    useDebounceEffect(() => {
        getList(filter);
    }, [filter], { wait: 200 })

    // 依赖数组应表达“何时需要重跑”，而不是把作用域里出现的函数一律加入

    // 4. 回调函数
    const changeFilter = (params) => {
        let new_filter = { ...filter, ...params };
        if (Object.keys(params).includes('search')) {
            new_filter.page = 1;
        }
        updates({ filter: new_filter });
    };

    // 5. 其他逻辑函数
    let handleTableChange = (pagination, filters, sorter) => {
        let filter_data = { ...filter };
        if (sorter.order) {
            filter_data.ordering = sorter.order === "ascend" ? sorter.field : "-" + sorter.field;
            filter_data.page = 1;
        } else {
            delete filter_data.ordering
        }
        updates({ filter: filter_data });
    }

    // 6. 渲染
    return (
        <div className="h-full flex flex-col space-y-[5px]">
            <Breadcrumb items={[{ title: '资源管理' }, { title: '模块名称' }]} />
            <div className="flex-1 h-0 bg-theme flex flex-col gap-[10px] p-[10px]">
                {/* 搜索 + 操作按钮 */}
                {/* 表格 */}
                {/* 分页 */}
                {/* 子组件/弹框 */}
            </div>
        </div>
    )
}

// 7. 默认导出
export default Index;
```

### 6.2 基础布局结构

```jsx
<div className="h-full flex flex-col space-y-[5px]">
    <Breadcrumb items={[{ title: '资源管理' }, { title: '模块名称' }]} />
    <div className="flex-1 h-0 bg-theme flex flex-col gap-[10px] p-[10px]">
        {/* 内容区 */}
    </div>
</div>
```

### 6.3 表格列规范

- **序号列**：`(filter.page - 1) * filter.size + index + 1`
- **状态列**：使用 `Tag` 组件，绿色表示正常/可用，红色表示异常/不可用
- **布尔状态**：使用 `CheckCircleFilled`（绿色）/ `CloseCircleFilled`（红色）图标
- **操作列按钮**：`size='small'`，`variant='link'`，授权/编辑用 `color='primary'`，删除/回收用 `color='danger'`
- **空值展示**：`'--'`
- **key**：必须使用唯一稳定标识，禁止使用索引
- **表头筛选优先**：表格字段如果有对应的搜索或筛选能力，优先使用 Ant Design Table 的 `filterDropdown`、`filters`、`filteredValue` 和 `onChange` 放在表头中；顶部搜索区只承载跨字段关键字、时间区间、全局状态、批量操作等不归属于单列的交互。

### 6.4 顶部操作按钮规范

```jsx
<div className='flex items-center space-x-[10px]'>
    <Button color='primary' variant='outlined'>全量操作</Button>
    <Button color='primary' variant='solid' disabled={selected.length === 0}>批量操作</Button>
    <Button color='danger' variant='solid' disabled={selected.length === 0}>批量删除</Button>
</div>
```

### 6.5 分页规范

```jsx
<Pagination
    className='flex justify-center'
    current={filter.page}
    total={list.count}
    pageSize={filter.size}
    onChange={(page, size) => { changeFilter({ page, size }) }}
    showSizeChanger={false}
    showTotal={total => `总计: ${total} 条数据`}
/>
```

### 6.6 行选择规范

```jsx
const rowSelection = {
    selectedRowKeys: selected,
    preserveSelectedRowKeys: true,
    onChange: (selectedRowKeys) => {
        updates({ selected: selectedRowKeys });
    },
};
```

---
