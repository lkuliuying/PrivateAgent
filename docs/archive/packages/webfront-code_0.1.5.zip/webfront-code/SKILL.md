---
name: webfront-code
description: 在用户需要生成、修改、重构或审查 React 18 / Vite / React Router v6 / Ant Design 5 / Tailwind CSS / Zustand / ahooks / service 接口代码时使用，确保代码遵循项目模块化、状态管理、接口服务、防御性编程、性能和 UTF-8 编码规范
---

# 前端团队 Vibe Coding Skill

本 Skill 用于指导 AI 在生成、修改、重构或审查 React 前端代码时遵循团队规范。为节省上下文消耗，`SKILL.md` 只保留每次必须读取的硬规则和 reference 索引；详细规范、模板和完整示例按任务需要读取 `references/`。

## 必读硬规则

- 技术栈固定为 React 18 函数组件 + Hooks、Vite、React Router v6、Ant Design 5.x、Tailwind CSS、Zustand、ahooks、`@ant-design/icons`。
- 禁止使用 Class 组件、`var`、双引号静态字符串、索引作为 key、渲染阶段执行副作用。
- 所有新增或修改文件必须使用 UTF-8 无 BOM；中文直接写中文，不写 Unicode 转义。
- 每个功能模块保持独立目录；禁止把多个模块的状态或接口混写在同一个 store/service 文件中。
- Zustand store 是模块复杂状态的唯一状态源；组件内简单状态可用 `useState`，复杂状态进入模块 store。
- 所有请求定义在 `services/模块名/` 下，组件中禁止直接写 URL。
- 空值统一展示 `'--'`；接口成功统一判断 `data?.status === 1`；列表空值防御性判断 `data?.results`。
- 列表 key 必须使用唯一稳定标识；复杂计算使用 `useMemo`。
- 接口函数、store action、复杂业务函数必须添加简洁中文注释；参数、返回值、边界条件或副作用不直观时使用 JSDoc。
- 表格展示字段存在对应搜索或筛选能力时，优先把交互放在表头筛选中；仅将跨字段关键字、时间区间、批量操作等不属于单列的能力放在顶部区域。
- 修改代码前先读取当前项目已有实现，并跟随本地目录、命名、组件和 service/store 模式。
- 安装新的依赖包后，必须检查对应 package.json 的 dependencies 或 devDependencies 是否已增加该依赖，并确认依赖分类符合用途。

## 按任务读取 References

- 基础角色、技术栈、核心原则、编码约束：读取 `references/core.md`。
- 目录结构、文件夹命名、文件命名：读取 `references/project-structure.md`。
- 接口服务、service 模板、统一导出：读取 `references/services.md`。
- `@/utils/method`、`@/utils/request`、工具函数完整实现：读取 `references/utils.md`。
- Zustand store 结构、Action、删除分页、函数组织：读取 `references/store.md`。
- 页面 `index.jsx`、表格、分页、筛选、行选择：读取 `references/page-components.md`。
- Drawer、Modal、表单、详情、确认弹框、授权弹框：读取 `references/drawer-modal.md`。
- Tailwind、`@/styles`、CSS Modules、CSS 属性顺序：读取 `references/styles.md`。
- 命名规范、组件语义、编码风格、JSX、Props、路由、错误处理：读取 `references/naming-and-code-style.md`。
- 完成前自检：读取 `references/checklist.md`。

## 执行流程

1. 根据任务类型读取最少必要的 reference；如果任务横跨页面、store、service，就读取对应多个文件。
2. 优先使用项目现有组件、hooks、service、store、样式对象和工具函数；不要重新发明已有能力。
3. 保持模块边界清晰：页面负责布局和交互，store 负责接口 Action 和模块状态，service 负责请求定义。
4. 生成或修改代码后，按 `references/checklist.md` 自检；涉及构建或高风险改动时运行项目已有校验命令。

## 资源维护

- 不把长模板、完整工具函数、长清单直接放回 `SKILL.md`。
- 新增长规范时优先放入 `references/`，并在本文件“按任务读取 References”中补入口。
- 保持 `description` 覆盖 React、Zustand、service、Ant Design、Tailwind、前端代码生成/修改/重构/审查等触发场景。
